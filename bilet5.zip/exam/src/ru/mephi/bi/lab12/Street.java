package ru.mephi.bi.lab12;

public class Street {

    public static void main(String[] args) {
        People nastya = new People();
        Trees oak = new Trees();
        nastya.makeBreath();
        oak.makeBreath();
        nastya.makeDeepBreath();
        oak.makeDeepBreath();
        nastya.getSick();
        oak.getSick();
    }

}
